import greengrasssdk
import json
import time
import subprocess

# some_file.py
#import sys
# insert at 1, 0 is the script path (or '' in REPL)
#sys.path.insert(1, '/home/pi/Dexter/GoPiGo3/Software/Python')

#import easygopigo3

client = greengrasssdk.client('iot-data')
cmd = "python /home/pi/Desktop/baixo.py"

def lambda_handler(event, context):
    client.publish(
        topic='hello/world/baixo',
        payload=json.dumps({'message': 'baixo'})
    )
    
    #returned_value = subprocess.call(cmd, shell=True)
    #returned_value = subprocess.Popen(['python', 'cima.py'], stdout=None, stderr=None, cwd='/home/pi/Desktop/', shell=True)
    #returned_value = subprocess.check_output(['python', '/home/pi/Desktop/cima.py'], cwd='/home/pi/Desktop', shell=True)
    returned_value = subprocess.check_output(['python', '/home/pi/Desktop/baixo.py'], cwd='/home/pi/Desktop', shell=False)
    #cmd = subprocess.Popen('test.exe', stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd='C:/test', shell=True)
    
    print('Texto do Subprocesso:', returned_value.decode("utf-8"))
    
    #gpg=EasyGoPiGo3()

    #gpg.forward()
    #time.sleep(3)
    #gpg.stop()
    
    return